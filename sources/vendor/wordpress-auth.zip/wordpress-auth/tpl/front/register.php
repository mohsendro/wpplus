<div class="auth-wrapper">
    <div class="alert" style="disply:none;">

    </div>
    <div class="register-wrapper">
        <?php if (isset($wp_auth_options['register_form_title'])) : ?>
        <h2><?php echo $wp_auth_options['register_form_title']; ?></h2>
        <?php endif; ?>
        <form action="" method="post" id="registerForm">
            <div class="form-row">
                <label for="user_first_name">نام :</label>
                <input type="text" name="user_first_name" id="user_first_name">
            </div>
            <div class="form-row">
                <label for="user_last_name"> نام خانوادگی :</label>
                <input type="text" name="user_last_name" id="user_last_name">
            </div>

            <div class="form-row">
                <label for="user_email">ایمیل :</label>
                <input type="email" name="user_email" id="user_email">
            </div>

            <div class="form-row">
                <label for="user_password">کلمه عبور :</label>
                <input type="password" name="user_password" id="user_password">
            </div>

            <div class="form-row">
                <button name="submitRegister">ثبت نام</button>
            </div>

        </form>
    </div>
</div> 