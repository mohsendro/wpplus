<?php
/*
Plugin Name: Elementor Jalaly Datepicker
Author URI:  mohsendroo@yahoo.com
Description: مینی افزونه ضروری برای شمسی سازی دیتاپیکر المنتور  
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

require_once('elementor-jalaly-datepicker-localization/localization.php'); 