<?php

    // $query_string = $_SERVER['REQUEST_URI']; var_dump($query_string);
    // add_query_arg();
    // $url_query_string = get_query_string();

    $type = "email";
    if( isset( $GET['action'] ) ) {

        $query_string = $_GET['action'];
        switch ( $query_string ) {
            case 'signup':
                if( $type == "email" ) include "email/signup.php";
                if( $type == "sms" ) include "sms/signup.php";
                break;
            case 'lostpassword':
                if( $type == "email" ) include "email/lostpasseord.php";
                if( $type == "sms" ) include "sms/lostpasseord.php";
                break;
            default:
                if( $type == "email" ) include "email/signin.php";
                if( $type == "sms" ) include "sms/signin.php";
                break;
        }

    } else {
        if( $type == "email" ) include "email/signin.php";
        if( $type == "sms" ) include "sms/signin.php";
    }

?>

