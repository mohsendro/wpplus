<?php //get_header(); ?>

<?php

// $list_errors = [
//     'empty' => 'تمامی فیلدهای الزامی می باشند',
// ];
// $errors = new WP_Error;

// if( isset( $_POST['SigninSubmit'] ) ){
// 	if( ! isset($_POST['signin_security']) || ! wp_verify_nonce( $_POST['signin_security'], 'signinNonce' ) )
// 		echo 'متاسفانه اجازه دسترسی ندارید!';
// }

function wpplus_validate(){

    if( isset( $_POST['signin_submit'] ) ) {

        $user_login = sanitize_text_field( $_POST['user_login'] );
        $user_pass  = sanitize_text_field( $_POST['user_pass'] );
        $rememberme = false;

        if( isset( $_POST['rememberme'] ) ) {
            $rememberme = true; 
        }

        if ( empty($user_login) ) echo 'خطا: شناسه‌ای نوشته نشده است.';
        if ( empty($user_pass) ) echo 'خطا: کادر رمز خالی است.';

        if( strpos($user_login, '@') ) {
            echo 'این یک ایمیل است';
        } else {
            echo 'این یک نام کاربری است';
        }

        $user = wp_authenticate($user_login, $user_pass);
        if( !is_wp_error($user) ) {
            // $first_name = $user->first_name;
            echo "اعتبار ورود معتبر است";
            wp_signon([
                'user_login'    => $user_login,
                'user_password' => $user_pass,
                'remember' => true
            ]);
            
        } else {
            echo "اعتبار ورود نامعتبر است.";
        }


    }

}
?>

<div class="notification">
    <?php wpplus_validate(); ?>
</div>

<form action="" method="POST" id="signin_form">

  <label for="user_login">نام کاربری یا نشانی ایمیل</label><br>
  <input type="text" name="user_login" id="" class="" value="" size="20" autocapitalize="off" ><br>

  <label for="user_pass">رمز عبور</label><br>
  <input type="password" name="user_pass" id="password" class="" value="" size="20">
  <!-- <i class="bi bi-eye-slash" id="togglePassword"></i> -->
  <!-- <button type="button" id="togglePassword">نمایش رمز عبور</button><br> -->

  <p class="forgetmenot">
    <label for="rememberme">مرا به خاطر بسپار</label>
    <input name="rememberme" type="checkbox" id="" value="">
  </p>

  <?php wp_nonce_field('signinNonce','signin_security', false, false); ?>

  <input type="submit" name="signin_submit" id="" class="" value="ورود"><br>

</form> 

<?php //get_footer(); ?>