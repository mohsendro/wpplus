<?php

defined( 'ABSPATH' ) || exit;

/** Enqueue Styles && Scripts */
function wpplus_enqueuing_signon_styles() {
 
	wp_register_style( 'signon-style', plugin_dir_url(__FILE__) . 'css/signon.css', false, '1.0.0' );
	wp_enqueue_style( 'signon-style' );

}

function wpplus_enqueuing_signon_scripts() {

    wp_enqueue_script("jquery");
	wp_register_script( 'signon-script', plugin_dir_url(__FILE__) . 'js/signon.js', false, '1.0.0' );
	wp_enqueue_script( 'signon-script' );

}

add_action( 'wp_enqueue_scripts', 'wpplus_enqueuing_signon_styles' );
add_action( 'wp_enqueue_scripts', 'wpplus_enqueuing_signon_scripts' );


/** Signin && Signup Page Slug */
function wpplus_generate_rewrite_rule_signon( $wp_rewrite ) {
    $wp_rewrite->rules = array_merge(
        ['signon/?$' => 'index.php?signon=1'],
        $wp_rewrite->rules
    );
}
add_filter( 'generate_rewrite_rules', 'wpplus_generate_rewrite_rule_signon');

function wpplus_query_vars_signon( $query_vars ) {
    $query_vars[] = 'signon';
    return $query_vars;
}
add_filter( 'query_vars', 'wpplus_query_vars_signon');

function wpplus_templates_signon() {
    $custom = intval( get_query_var( 'signon' ) );
    if ( $custom ) {
        include plugin_dir_path( __FILE__ ) . 'templates/signon.php';
        die;
    }
}
add_action( 'template_redirect', 'wpplus_templates_signon');


/** Include Ajax Files && Functions */
// include plugin_dir_path( __FILE__ ) . 'ajax/ajax.php' ;