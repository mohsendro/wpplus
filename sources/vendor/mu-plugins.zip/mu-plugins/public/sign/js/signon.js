// window.onload = function() {

//     const togglePassword = document.getElementById("togglePassword");
//     const password = document.getElementById("password");
//     // console.log(togglePassword, password);

//     togglePassword.addEventListener("click", function () {
//         // toggle the type attribute
//         const type = password.getAttribute("type") === "password" ? "text" : "password";
//         password.setAttribute("type", type);
        
//         // toggle the icon
//         this.classList.toggle("bi-eye");
//     });

//     // prevent form submit
//     const form = document.getElementById("signin_form");
//     form.addEventListener('submit', function (e) {
//         e.preventDefault();
//     });

// }
