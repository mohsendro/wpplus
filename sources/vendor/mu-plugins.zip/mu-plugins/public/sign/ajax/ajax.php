<?php

// function wpplus_wp_ajax_caculate_function() {
//     // var_dump($_POST);
//     $numberOne = $_POST['numberOne'];
//     $numberTwo = $_POST['numberTwo'];

//     wp_send_json( [
//         'success'   => true,
//         'result'    => $numberOne + $numberTwo,
//     ] );
// }
// add_action( 'wp_ajax_caculate', 'wpplus_wp_ajax_caculate_function' );