<?php

defined('ABSPATH') || exit;

function wpplus_enqueuing_general_styles() {
 
	wp_register_style( 'general-style', plugin_dir_url(__FILE__) . 'css/style.css', false, '1.0.0' );
	wp_enqueue_style( 'general-style' );

}

function wpplus_enqueuing_general_scripts() {

	wp_register_script( 'general-script', plugin_dir_url(__FILE__) . 'js/script.js', false, '1.0.0' );
	wp_enqueue_script( 'general-script' );

}

add_action( 'wp_enqueue_scripts', 'wpplus_enqueuing_general_styles' );
add_action( 'wp_enqueue_scripts', 'wpplus_enqueuing_general_scripts' );


/*****************************************************************************************************/














