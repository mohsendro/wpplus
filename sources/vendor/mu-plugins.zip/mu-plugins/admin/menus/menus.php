<?php

// function wpplus_remove_menus(){
 
//   remove_menu_page( 'jet-dashboard' );
 
// }
// add_action( 'admin_init', 'wpplus_remove_menus' );

function wpplus_menu_order($menu_ord) {

    // var_dump($menu_ord);
    if (!$menu_ord) return true;
    return array(
     'index.php',
     'separator1',
     'edit.php?post_type=page',
     'edit.php',
     'edit-comments.php',
     'upload.php',
     'separator2',
     'themes.php',
     'plugins.php',
     'users.php',
     'tools.php',
     'options-general.php',
     'separator-last',
 	);
   
}
add_filter('custom_menu_order', 'wpplus_menu_order');
add_filter('menu_order', 'wpplus_menu_order');