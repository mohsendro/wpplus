<?php

function wpplus_enqueuing_admin_styles() {
 
	wp_register_style( 'admin', plugin_dir_url(__FILE__) . 'css/admin.css', false, '4.2.1' );
	wp_enqueue_style( 'admin' );

}

function wpplus_enqueuing_public_styles() {

	wp_register_style( 'public', plugin_dir_url(__FILE__) . 'css/public.css', false, '4.2.1' );
	wp_enqueue_style( 'public' );

}

add_action( 'wp_enqueue_scripts', 'wpplus_enqueuing_public_styles' );
add_action( 'admin_enqueue_scripts', 'wpplus_enqueuing_admin_styles' );
add_action( 'login_enqueue_scripts', 'wpplus_enqueuing_admin_styles' );