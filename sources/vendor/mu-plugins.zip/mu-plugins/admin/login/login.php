<?php

class Style {
    
    public function __construct( ){
        add_action( 'login_enqueue_scripts', array($this, 'wpplus_enqueuing_admin_styles') );
    }

    public function wpplus_enqueuing_admin_styles(){
        wp_register_style( 'login-style', WPPLUS_DIR_URL . 'admin/login/css/login.css', false, '4.2.1' );
		wp_enqueue_style( 'login-style' );
    }
  
}

class Logo {

    public $logo = true; // for LogoActive Method
    public $url = WPPLUS_DIR_URL . 'admin/login/img/logo.png'; // for LogoImage Method

    public function __construct() {      
        if($this->logo == true){
            $this->LogoActive();
        }
        else{
            return false;
        }
    }

    public function LogoActive(){
        if( $this->logo == true ){
            add_filter( 'login_title', array($this, 'PageTitle') );
            add_filter( 'login_headerurl', array($this, 'LogoUrl') );
            add_filter( 'login_headertitle', array($this, 'LogoTitle') );
            add_action( 'login_enqueue_scripts', array($this, 'LogoImage') );
        }
    }

    public function PageTitle($origtitle){
        return "بخش ورود مدیر سایت";
    }

    public function LogoUrl(){
        return home_url();
    }

    public function LogoTitle(){
        return 'توسعه توسط نوین مارکتینگ';
    }

    public function LogoImage(){ 
        ?> <style type="text/css">
            #login h1 a { background-image: url( <?php echo $this->url; ?>); }
        </style> <?php 
    }

}

class RenameUrl {

    private $rewrite_url  = "vorod";
    private $redirect_url = "404.php";
    private $die_massage  = "اجازه دسترسی نداری فضول خان!";
    private $wp_login_php;
    protected static $instance = null;

    public function __construct() {
        add_action( 'plugins_loaded', array( $this, 'plugins_loaded' ), 2 );
        add_action( 'wp_loaded', array( $this, 'wp_loaded' ) );
        add_filter( 'site_url', array( $this, 'site_url' ), 10, 4 );
    }

    private function path() {
        return trailingslashit( dirname( __FILE__ ) );
    }

    private function use_trailing_slashes() {

        // return ( '/' === substr( get_option( 'permalink_structure' ), -1, 1 ) );
        return ( ' ' === substr( get_option( 'permalink_structure' ), -1, 1 ) );

    }

    private function user_trailingslashit( $string ) {

        return $this->use_trailing_slashes()
            ? trailingslashit( $string )
            : untrailingslashit( $string );

    }

    private function wp_template_loader() {

        global $pagenow;

        $pagenow = 'index.php';

        if ( ! defined( 'WP_USE_THEMES' ) ) {

            define( 'WP_USE_THEMES', true );

        }

        wp();

        if ( $_SERVER['REQUEST_URI'] === $this->user_trailingslashit( str_repeat( '-/', 10 ) ) ) {

            $_SERVER['REQUEST_URI'] = $this->user_trailingslashit( '/wp-login-php/' );

        }

        require_once( ABSPATH . WPINC . '/template-loader.php' );

        die;

    }

    public function new_login_url( $scheme = null ) {

        if ( get_option( 'permalink_structure' ) ) {

            return $this->user_trailingslashit( home_url( '/', $scheme ) . $this->rewrite_url );

        } else {

            return home_url( '/', $scheme ) . '?' . $this->rewrite_url;

        }

    }

    public static function get_instance() {
        
        // If the single instance hasn't been set, set it now.
        if ( null == self::$instance ) {
            self::$instance = new self;
        }

        return self::$instance;
    }

    public function plugins_loaded() {

        global $pagenow;

        // if ( ! is_multisite()
        //     && ( strpos( $_SERVER['REQUEST_URI'], 'wp-signup' )  !== false
        //         || strpos( $_SERVER['REQUEST_URI'], 'wp-activate' ) )  !== false ) {

        //     wp_die( __( 'This feature is not enabled.', 'wps-hide-login' ) );

        // }

        $request = parse_url( $_SERVER['REQUEST_URI'] );

        if ( ( strpos( $_SERVER['REQUEST_URI'], 'wp-login.php' ) !== false
                || untrailingslashit( $request['path'] ) === site_url( 'wp-login', 'relative' ) )
            && ! is_admin() ) {

            $this->wp_login_php = true;

            $_SERVER['REQUEST_URI'] = $this->user_trailingslashit( '/' . str_repeat( '-/', 10 ) );

            $pagenow = 'index.php';

        } elseif ( untrailingslashit( $request['path'] ) === home_url( $this->rewrite_url, 'relative' )
            || ( ! get_option( 'permalink_structure' )
                && isset( $_GET[$this->rewrite_url] )
                && empty( $_GET[$this->rewrite_url] ) ) ) {

            $pagenow = 'wp-login.php';

        }

    }

    public function wp_loaded() {

        global $pagenow;

        if ( is_admin()
            && ! is_user_logged_in()
            && ! defined( 'DOING_AJAX' ) ) {

            status_header(404);
            nocache_headers();
            // include( get_404_template() );
            // wp_redirect('404.php');
            exit;
        }

        $request = parse_url( $_SERVER['REQUEST_URI'] );

        if ( $pagenow === 'wp-login.php'
            && $request['path'] !== $this->user_trailingslashit( $request['path'] )
            && get_option( 'permalink_structure' ) ) {

            wp_safe_redirect( $this->user_trailingslashit( $this->new_login_url() )
                . ( ! empty( $_SERVER['QUERY_STRING'] ) ? '?' . $_SERVER['QUERY_STRING'] : '' ) );

            die;

        } elseif ( $this->wp_login_php ) {

            if ( ( $referer = wp_get_referer() )
                && strpos( $referer, 'wp-activate.php' ) !== false
                && ( $referer = parse_url( $referer ) )
                && ! empty( $referer['query'] ) ) {

                parse_str( $referer['query'], $referer );

                if ( ! empty( $referer['key'] )
                    && ( $result = wpmu_activate_signup( $referer['key'] ) )
                    && is_wp_error( $result )
                    && ( $result->get_error_code() === 'already_active'
                        || $result->get_error_code() === 'blog_taken' ) ) {

                    wp_safe_redirect( $this->new_login_url()
                        . ( ! empty( $_SERVER['QUERY_STRING'] ) ? '?' . $_SERVER['QUERY_STRING'] : '' ) );

                    die;

                }

            }

            $this->wp_template_loader();

        } elseif ( $pagenow === 'wp-login.php' ) {

            global $error, $interim_login, $action, $user_login;

            @require_once ABSPATH . 'wp-login.php';

            die;

        }

    }

    public function site_url( $url, $path, $scheme, $blog_id ) {

        return $this->filter_wp_login_php( $url, $scheme );

    }

    public function filter_wp_login_php( $url, $scheme = null ) {

        if ( strpos( $url, 'wp-login.php' ) !== false ) {

            if ( is_ssl() ) {

                $scheme = 'https';

            }

            $args = explode( '?', $url );

            if ( isset( $args[1] ) ) {

                parse_str( $args[1], $args );

                $url = add_query_arg( $args, $this->new_login_url( $scheme ) );

            } else {

                $url = $this->new_login_url( $scheme );

            }

        }

        return $url;

    }
    
}

class RedirectUrl {
  
  public $request_url;
  private $die_massage = "اجازه دسترسی نداری فضول خان!";
  private $die_title   = "عدم دسترسی";

  public function __construct(){
    add_action( 'init', array($this, 'managment_redirect_urls') );
  }

  public function managment_redirect_urls() {

    if ( is_multisite() ) return;
    if ( ! is_user_logged_in() && strpos( $_SERVER['REQUEST_URI'], 'wp-admin' ) && ( ! defined( 'DOING_AJAX' ) || ! DOING_AJAX ) ) 
            wp_die( $this->die_massage, $this->die_title );
    if ( //strpos( $_SERVER['REQUEST_URI'], 'login') ||
         strpos( $_SERVER['REQUEST_URI'], 'wp-login') ||
         strpos( $_SERVER['REQUEST_URI'], 'wp-register') ||
         strpos( $_SERVER['REQUEST_URI'], 'wp-signin') ||
         strpos( $_SERVER['REQUEST_URI'], 'wp-signup') ||
         strpos( $_SERVER['REQUEST_URI'], 'wp-activate') ) {
      wp_die( $this->die_massage, $this->die_title );
    }

  }
  
}

class RedirectLoginout {

    public $login_url = ' ';
    public $logout_url = ' ';

    public function __construct() {
        add_filter( 'login_redirect', array( $this, 'login_redirect_function' ) );
        add_filter( 'logout_redirect', array( $this, 'logout_redirect_function' ) );
    }

    public function login_redirect_function( $user ) {
        //is there a user to check?
        // if ( isset( $user->roles ) && is_array( $user->roles ) ) {
            //check for admins
            if ( @in_array( 'administrator', $user->roles ) ) {
                // redirect them to the default place
                return $redirect_to;
            } else {
                return home_url();
            }
        // } else {
        //     return $redirect_to;
        // }
    }

    public function logout_redirect_function( $requested_redirect_to ) {
        $requested_redirect_to = home_url();
        return $requested_redirect_to;
    }

}

$ob_style = new Style;
$ob_logo  = new Logo;
$ob_url   = new RenameUrl;
$ob_redirect = new RedirectUrl;
$ob_loginout = new RedirectLoginout;













/******************* WP Login Url For All Sections Site login redirect if user not logged in *******************/
// wp_login_form  wp_login  wp_login_url  wp_register  wp_logout  wp_logout_url  wp_loginout
// admin_url  get_admin_url
// home_url  get_home_url  get_home_path  site_url  get_site_url
// content_url  includes_url  wp_upload_dir

$url_vorod = $_SERVER['REQUEST_URI'];

function wpplus_login_url_rediret( $login_url, $redirect, $force_reauth ) {
    // return home_url( '/my-login-page/?redirect_to=' . $redirect );
    return home_url('signon');
}

function wpplus_register_url_rediret( $url ) {
    return home_url('signon');
}

function wpplus_lost_password_url_rediret( $lostpassword_url, $redirect ) {
    return home_url('signon');
}

function wpplus_logout_url_rediret( $logout_url, $redirect ) {
    if( is_admin() ) {
        return $logout_url;
    }
    return home_url();
}

function wpplus_admin_url_rediret() {
    return home_url();
}

if( ! strpos( $url_vorod, 'vorod' ) ) {
    add_filter( 'login_url', 'wpplus_login_url_rediret', 10, 3 );
    add_filter( 'register_url', 'wpplus_register_url_rediret' );
    add_filter( 'lostpassword_url', 'wpplus_lost_password_url_rediret', 10, 2 );
    add_filter( 'logout_url', 'wpplus_logout_url_rediret', 10, 2 );
    // add_filter( 'admin_url', 'wpplus_admin_url_rediret', 10 );
}

/******************* Comment login redirect if user not logged in *******************/
// function comment_form_defaults_massage( $fields ){
//     $fields['must_log_in'] = 'برای ثبت نظر باید وارد شوید';
//     return $fields ;
// }
// add_filter( 'comment_form_fields', 'comment_form_defaults_massage' );

function comment_form_defaults_massage( $defaults ){
    $defaults['must_log_in'] = 'برای ثبت نظر باید وارد شوید';
    return $defaults;
}
// add_filter( 'comment_form_defaults', 'comment_form_defaults_massage' );

function comment_reply_link_massage( $link, $args, $comment, $post) {
    return $args["login_text"] = 'برای پاسخ به نظر باید وارد شوید';
}
// add_filter( 'comment_reply_link', 'comment_reply_link_massage', 10 ,4);

/******************* Disable Default Widgets Wordpress *******************/
function unregister_default_widgets() {
    unregister_widget('WP_Widget_Meta');
    unregister_widget('WP_Nav_Menu_Widget');
}
// add_action('widgets_init', 'unregister_default_widgets', 11);

function add_login_logout_link($items, $args) {
    ob_start();
    wp_loginout('index.php');
    $loginoutlink = ob_get_contents();
    ob_end_clean();
    $items .= '<li>'. $loginoutlink .'</li>';
return $items;
}
// add_filter('wp_nav_menu_items', 'add_login_logout_link', 10, 2);